#include <iostream>

#include "Manager.h"
#include "Developer.h"
#include "Administrator.h"

int main()
{
    //не нужен?

}
